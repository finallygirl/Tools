//
//  main.m
//  Day01-OC基础语法
//
//  Created by kid.wang on 2025/4/11.
//
/*
 1. OC相对于C
    a. 在C的基础上新增了一小部分面向对象的语法。
    b. 将C的复杂的，繁琐的语法封装的更为简单。
    c. OC完全兼容C语言。
 
 2. OC程序的源文件的后缀名是.m m代表message 代表OC中最重要的一个机制 消息机制。
    C程序的源文件的后缀名.c
 
 3. main函数仍然是OC程序的入口和出口。
    int类型的返回值 代表程序的结束状态。
    main函数的参数：仍然可以接受用户在运行程序的时候传递数据给程序。
                  参数可以不要。
 
 4. #import指令。
 1). 以#号开头， 是一个预处理指令。(预处理指令执行时机在编译之前)
 2). 作用：是#include指令的增强版，将文件的内容在预编译的时候拷贝写指令的地方。
 3). 增强：同一个文件无论#import多少次，只会包含1次。
          如果#include指令要实现这个效果 就必须要配合条件编译指令来实现。
          而#import指令只需要直接包含就可以 其他什么都不用做。
 4). 简要原理：#import指令在包含文件的时候，底层会先判断这个文件是否被包含 如果被包含就会略过 否则才会包含。
 
 5. 框架
 1). 是一个功能集 苹果或第三方事先将一些程序在开发程序的时候经常用到的功能事先写好。把这些功能封装在1个1个的类或者函数之中。
     这些函数和类的集合就叫做框架。
     有点像C语言的函数库。
 2). Foundation框架。
     Foundation：基础 基本。这个框架中提供了一些最基础的功能 输入和输出。 一些数据类型。
     Foundation.h这个文件中包含了Foundation框架中的其他的所有的头文件。
     所以，我们只要包含Foundation.h 就相当于包含了Foundation框架中所有的头文件。
     那么Foundation框架中的所有的函数和类就可以直接使用。
 
 6. @autoreleasepool是自动释放池
    可以将代码写在自动释放池之中，或者干脆把这个自动释放池删除 不会有任何影响。
 
 7. NSLog函数。
    1). 作用：是printf函数的增强版，向控制台输出信息。
    2). 语法：NSLog(@"格式控制字符串", 变量列表);
        最简单的语法：NSLog(@"要输出的信息");
    3). 增强：
        a. 输出一些调试相关信息。
           2025-04-11 11:05:20.628 Day01-OC基础语法[784:210576] Hello, World!
           执行这段代码的时间。
           程序的名称。
           进程编号。
           线程编号。
           输出的信息。
        b. 会自动换行，在输出完信息之后 会自动换行。
        c. OC中其实新增了一些数据类型。NSLog函数不仅仅可以输出C数据类型变量的值，还可以输出OC新增的数据类型的变量的值。
    4). 用法和printf函数差不多。一样可以输出变量的值，并且占位符和用法都一样。
    5). 使用注意：
        a. NSLog函数的第一个参数前面必须要加一个'@'符号。
        b. 如果手贱在字符串的末尾加了1个'\n'代表换行，那么函数的自动换行功能就会失效。
 
 8. 字符串
    1). C语言的字符串的存储方式
        a. 使用字符数组存储
        b. 使用字符指针
    2). OC中设计了1个更为好用的用来存储字符串的一个类型。NSString
        NSString 类型的指针变量 专门用来存储OC字符串的地址。
    3). OC的字符串常量必须要使用1个前缀'@'符号。
        "jack" 这是一个 C语言的字符串。
       @"jack" 这是一个OC语言的字符串常量。
        NSString类型的指针变量，只能存储OC字符串的地址。
        NSString *str = @"jack";
    4). 总结
        a. 在OC中专门设计了1个NSString类型来存储字符串。
        b. 字符串分为C字符串和OC字符串。
           字符串如果没有'@'前缀 那么这个字符串常量就是1个C字符串。
           字符串如果有'@'前缀 那么这个字符串常量就是OC字符串。
           所以OC字符串常量的前面必须要加1个'@'符号。
        c. NSString类型的指针变量 只能存储OC字符串。
           NSString *str = @"jack";
    5). 注意：
        1). NSLog函数的第一个参数是1个OC字符串，所以NSLog函数的第一个实惨应该以'@'符号开头。
        2). 如果要使用NSLog函数输出OC字符串的值，那么使用占位符%@
 
 9. NS前缀。
    NextStep  --->  Cocoa  --->  Foundation框架之中。
 
 10. @符号
     1). 将C字符串转换为OC字符串。
         "jack"  @"jack"
     2). OC中的绝大部份的关键字都是以'@'符号开头。
 
 11. 注释
     和C语言的注释一摸一样，分为单行注释和多行注释。
 
 12. 函数的定义和调用。
     与C语言的函数的定义和调用是一样的。
 
 */
/*
 1. OC程序的编译、链接、执行。
    1). 在.m文件中写上符合OC语法规范的源代码。
    2). 使用编译器将源代码编译为目标文件。
        cc -c xx.m
        a. 预处理
        b. 检查语法，如果语法有问题，直接报错，不会进行下一步编译
        c. 编译
    3). 链接
        cc xx.o
        如果程序中使用到了框架中的函数或者类，那么在链接的时候，就必须要告诉编译器
        去那一个框架中找这个函数或者类。
        cc xx.o -framework 框架名称。
        cc main.o -framework Foundation
        程序中用到了那一个框架中的功能 那么就在这个地方告诉编译器。
    4). 链接成功以后 就会生成1个a.out可执行文件 执行就可以了。
 
 2. 我们点击运行按钮，所有的事情Xcode就帮我买自动做了。
 
 3. OC程序和C程序各个阶段的后缀名对比
    源文件         目标文件        可执行文件
C     .c            .o            .out
OC    .m            .o            .out
 
 */
/*
 1. OC中的数据类型
    1). OC中支持C语言中的所有数据类型。
        a. 基本数据类型
           int double float char
        b. 构造类型
           数组 结构体 枚举
        c. 指针类型
           int *p1;
        d. 空类型
           void
        e. typedef自定义类型。
    2). BOOL类型。
        1). 可以存储YES或者NO中的任意1个数据。
        2). 一般情况下BOOL类型的变量用来存储条件表达式的结果。如果条件表达式成立 那么结果就是YES
            如果条件表达式不成立 结果就是NO
        3). BOOL的本质。
            typedef signed char BOOL;
            实际上BOOL类型的变量 是一个有符号的char变量。
            #define YES ((BOOL)1)
            #define NO  ((BOOL)0)
            YES 实际上就是 1
            NO  实际上就是 0
    3). Boolean
        a. Boolean类型的变量可以存储true或者false
        b. 一般情况下Boolean类型的变量用来存储条件表达式的结果。如果条件表达式成立 那么结果就是true
           如果条件表达式不成立 结果就是false
        c. 本质
           typedef unsigned char Boolean;
           #define true 1
           #define false 0
    4). class 类型。类。
    5). id类型 万能指针。
    6). nil与NULL差不多。
    7). SEL方法选择器。
    8). block 代码段。
 */
/*
 1. 类和对象的关系：
    类是多个类似对象抽象总结而成，对象是类的实例化体现。
    类是对一群具体相同特征行为事物的统称，特点是抽象的不能直接去使用，
    对象是现实生活中具体的存在，特点是看的见摸得着，拿过来可以直接使用。
    面向对象的最大优点是，后期易于维护。
    面向过程是亲力亲为，面向对象是找人去做。
    对象的特点: 对象拥有类中定义的所有的成员。
    对象中的成员可以直接访问。
    同一个类可以创建N个对象，并且这N个对象毫无关系。
    在方法中可以直接访问属性，访问的就是当前对象的属性。
 
 2. 如何设计一个类：
    类的作用：用来描述一群具有相同特征和行为的事物的。
    设计类的三要素：
    -> 类的名字，你要描述的这类事物叫什么名字。
    -> 这类事物具有的相同的特征，这类事物拥有什么。
    -> 这类事物具有的共同的行为，这类事物会做什么。
 
 3. 如何定义类
    1). 定义类的语法：
        a. 位置，直接写在源文件之中，不要写在main函数之中。
        b. 语法：类的定义分为两个部分：
           -> 类的声明
           @interface 类名 : NSObject
           {
             这类事物具有的共同的特征，将他们定义为变量。
           }
           功能就是1个方法，将方法的声明写在这里。
           @end
           -> 类的实现
           @implementation 类名
           将方法的实现写在这里。
           @end
    2). 几点注意
        a. 类必须要有声明和实现
        b. 类名用你描述的事物的名称来命名就可以了。
           类名的每一个单词的首字母必须要以大写开头(大驼峰式命名法)。
        c. NSObject是什么意思？不用管，照写就可以了。
        d. 用来表示这类事物的共同的特征的变量必须要定义在'@'interface的大括号之中。
        e. 定义在大括号之中用来表示这类事物的共同的特征的变量，我们叫做：
           属性，成员变量，实例变量，字段...
        f. 为类定义属性的时候，属性的名称必须要以_开头 下划线开头。(规范)
    3). 语法是固定的：
        @interface 类名 : NSObject
        {
            这类事物具有的共同的特征定义为变量。
            数据类型 变量名1;
            数据类型 变量名2;
            ...
        }
        @end
        @implementation 类名
        @end
 
 4. 类是无法直接使用的，如果非要使用这个类的话，就必须要先找到这个类中的一个具体存在。
    再使用这个对象。
    如何创建一个类的对象呢？
    语法: 类名 *对象名 = [类名 new];
    e.g.: Person *p1 = [Person new];
          根据Person这个类的模版，创建了1个对象名字叫做p1。
          p1对象的特点：
          -> 可以直接使用。
          -> 类中定义的东西 这个对象中也有 不会多也不会少。
 5. 如何使用对象
    如何访问对象的属性：
    1). 默认情况下，对象的属性是不允许被外界直接访问的。
        如果允许对象的属性可以被外界访问，那么就在声明属性的时候加一个'@'public关键字。
    2). 访问对象的属性的方式
        对象名->属性名 = 值;
        对象名->属性名;
        (*对象名).属性名;
        平时使用的时候，使用->
 
 6. 方法的声明实现和调用
    一类事物不仅具有相同的特征还具有相同的行为。
    行为就是一个功能，C语言中使用函数来表示一个功能。
    OC的类具有的行为，我们使用方法来表示。
    方法和函数都表示一个功能。
    -> 方法的声明
    @interface 类名 : NSObject
    {
        属性 属性表示类的特征。
    }
    方法的声明; 方法表示类的功能(行为)。
    @end
    -> 方法的实现
    @implementaction 类名
    方法的实现;
    @end
 
 7. 无参数的方法。
    1). 声明
        a. 位置：在'@'interface的大括号的外面。
        b. 语法：
           - (返回值类型)方法名称;
           - (void)run;
           表示声明了1个无返回值并且无参数的方法，方法名字叫做run
    2). 实现
        a. 位置：在'@'implementation之中实现
        b. 实现的语法:
           将方法的声明拷贝到'@'implementation之中 去掉分号 追加大括号一对 将方法实现的代码写在大括号之中。
    3). 调用
        a. 方法是无法直接调用的，因为类是不能直接使用的，必须要先创建对象。
           那么这个对象中就有类中的属性和方法了 就可以调用对象的方法了。
        b. 调用对象的方法。
           [对象名 方法名];
 
 8. 带1个参数的方法。
    1). 声明
        a. 位置：在'@'interface的大括号的外面。
        b. 语法：
           - (返回值类型)方法名称:(参数类型)形参名称;
           - (void)eat:(NSString *)foodName;
           定义了1个方法，这个方法没有返回值。
           这个方法的名字叫做eat:
           这个方法有1个参数，类型是NSString *类型的 参数的名字叫做foodName
    2). 实现
        a. 位置: 在'@'implementation之中实现
        b. 语法: 将方法的声明拷贝到'@'implementation之中 去掉分号 追加大括号一对 将方法实现的代码写在大括号之中。
    3). 调用
        a. 方法是无法直接调用的，因为类是不能直接使用的，必须要先创建对象。
           那么这个对象中就有类中的属性和方法了 就可以调用对象的方法了。
        b. 调用语法:
           [对象名 方法名:实参];
 
    方法头中的数据类型都要用1个小括号括起来。
    - (返回值类型)方法名称:(参数类型)参数名称;
 
 9. 带多个参数的方法。
    1). 声明
        a. 位置：在'@'interface的大括号的外面。
        b. 语法：
           - (返回值类型)方法名称:(参数类型)形参名称1 :(参数类型)形参名称2 :(参数类型)形参名称3;
           - (int)sum:(int)num1 :(int)num2;
           表示声明了1个方法，这个方法的返回值类型是int类型的。
           方法的名称叫做 sum: :
           有2个参数，参数类型都是int类型 参数名称叫做num1 num2
    2). 实现
        a. 位置: 在'@'implementation之中实现
        b. 实现的语法: 将方法的声明拷贝到'@'implementation之中 去掉分号 追加大括号一对 将方法实现的代码写在大括号之中。
    3). 调用
        a. 方法是无法直接调用的，因为类是不能直接使用的，必须要先创建对象。
           那么这个对象中就有类中的属性和方法了 就可以调用对象的方法了。
        b. 调用带多个参数的语法:
           [对象名 方法名:实参1 :实参2 :实参3];
 
 10. 带参数的方法声明的规范：
     1). 如果方法只有1个参数，要求最好这个方法的名字叫做 xxxWith:
         xxxWithXxx: eatWith: eatWithFood:
         这样写的话，那么调用方法的时候看起来就像是1条完整的语句，提高了我们代码的阅读性。
         遵守的规范: 就是让我们的方法调用的时候看起来像1条完整的语句。
     2). 如果方法有多个参数 建议这个方法名称:
         方法名With:(参数类型)参数名称 and:(参数类型)参数名称 and:(参数类型)参数名称;
         - (int)sumWith:(int)num1 and:(int)num2;
         sunWith: and:
         更详细的写法
         方法名With参数1:(参数类型)参数名称 and参数2:(参数类型)参数名称 and参数3:(参数类型)参数名称;
  */
/*
 其他使用注意：
 1. 同一个类可以创建无数个对象。
 2. 同一个类的多个对象之间毫无关系。
    虽然他们拥有相同的属性和方法
    属性的值是不会相互影响的
 3. 在方法的实现中，可以直接访问属性
    在方法中访问的属性是谁的属性呢？
    这个方法是通过那1个对象来调用的，那么方法中的直接访问的属性就是那1个对象的。
 */

//#import <Foundation/Foundation.h>
//
//@interface Student : NSObject{
//    @public
//    NSString *_name;
//    int _age;
//    float _yuwen;
//    float _shuxue;
//    float _english;
//    float _tiZhong;
//}
//- (void) run;
//- (void) eat;
//@end
//
//@implementation Student
//- (void)run{
//    _tiZhong -= 0.5f;
//    NSLog(@"目前的体重是:%.2f",_tiZhong);
//}
//- (void)eat{
//    _tiZhong += 0.7f;
//    NSLog(@"目前的体重是:%.2f",_tiZhong);
//}
//@end
//
//int main(int argc, const char * argv[]) {
//    Student *s1 = [Student new];
//    s1->_name = @"kid";
//    s1->_age = 18;
//    s1->_yuwen = 98.5f;
//    s1->_shuxue = 100.0f;
//    s1->_english = 99.5f;
//    s1->_tiZhong = 100.0f;
//    NSLog(@"我叫%@ 年龄%d岁 语文成绩是%.2f分", s1->_name, s1->_age, s1->_yuwen);
//    [s1 run];
//    [s1 run];
//    [s1 eat];
//    [s1 eat];
//    [s1 run];
//    [s1 run];
//    return 0;
//}
#import <Foundation/Foundation.h>

// 狗类
@interface Dog : NSObject{
    @public
    NSString *_color;
    float _speed;
    NSString *_sex;
    float _weight;
}
- (void) eat;
- (void) say;
- (void) run;
@end

@implementation Dog
- (void) eat{
    NSLog(@"开始吃");
    _weight += 0.5f;
    NSLog(@"吃完体重是%.2f", _weight);
    NSLog(@"结束吃");
}
- (void) say{
    NSLog(@"开始叫");
    NSLog(@"颜色:%@, 速度:%.2f, 性别:%@, 体重:%.2f", _color, _speed, _sex, _weight);
    NSLog(@"结束叫");
}
- (void) run{
    NSLog(@"开始跑");
    NSLog(@"奔跑的速度为%.2f", _speed);
    _weight -= 0.5f;
    NSLog(@"跑完体重是%.2f", _weight);
    NSLog(@"结束跑");
}
@end

// 学生类
@interface Student : NSObject{
    @public
    NSString *_name;
    NSString *_brith;
    int _age;
    int _height;
    float _weight;
    NSString *_sex;
    int _c;
    int _oc;
    int _ios;
}
- (void) run;
- (void) eat;
- (void) study;
- (void) sleep;
- (void) sumWithC:(int)C andOC:(int)OC andIOS:(int)IOS;
- (void) avgWithC:(int)C andOC:(int)OC andIOS:(int)IOS;
@end

@implementation Student
- (void) run{
    NSLog(@"开始跑");
    _height += 10;
    _weight -= 0.5f;
    NSLog(@"跑完体重是%.2f", _weight);
    NSLog(@"跑完身高是%d", _height);
    NSLog(@"结束跑");
}
- (void) eat{
    NSLog(@"开始吃");
    _height += 10;
    _weight += 0.5f;
    NSLog(@"吃完体重是%.2f", _weight);
    NSLog(@"吃完身高是%d", _height);
    NSLog(@"结束吃");
}
- (void) study{
    NSLog(@"开始学");
    _c += 1;
    _oc += 1;
    _ios += 1;
    NSLog(@"学完的成绩是:C语言 %d分,OC %d分,iOS %d分", _c, _oc, _ios);
    NSLog(@"结束学");
}
- (void) sleep{
    NSLog(@"开始睡");
    NSLog(@"姓名:%@, 生日:%@, 年龄:%d, 身高:%d, 体重:%.2f, 性别:%@, C语言成绩:%d分, OC成绩:%d分, iOS成绩:%d分", _name, _brith, _age, _height, _weight, _sex, _c, _oc, _ios);
    NSLog(@"结束睡");
}
- (void) sumWithC:(int)C andOC:(int)OC andIOS:(int)IOS{
    int num = C + OC + IOS;
    NSLog(@"总分为: %d分",num);
}
- (void) avgWithC:(int)C andOC:(int)OC andIOS:(int)IOS{
    int num = (C + OC + IOS)/3;
    NSLog(@"平均分为: %d分", num);
}
@end

// 车类
@interface Car : NSObject{
    @public
    NSString *_pinpai;
    NSString *_type;
    NSString *_color;
    int _zuoWeiCount;
    int _lunZiCount;
    int _youCount;
}
- (void) run;
- (void) stop;
- (void) addYou;
@end

@implementation Car
- (void) run{
    _youCount -= 1;
    NSLog(@"当前油量为:%d", _youCount);
}
- (void) stop{
    NSLog(@"%@牌汽车停止了", _pinpai);
}
- (void) addYou{
    _youCount += 5;
    NSLog(@"当前油量为:%d", _youCount);
}
@end

// 球类
@interface Ball : NSObject{
    @public
    NSString *_name;
    int _qiuYuanCount;
    int _jiaoLianCount;
    int _winCount;
    int _loseCount;
}
- (void) show;
@end

@implementation Ball
- (void) show{
    NSLog(@"%@队，有%d名队员，有%d名教练，赢%d场，输%d场。", _name, _qiuYuanCount, _jiaoLianCount, _winCount, _loseCount);
}
@end

// 电脑类
@interface Computer : NSObject {
    @public
    NSString *_cpu;
}
- (void) start;
@end

@implementation Computer
- (void) start{
    NSLog(@"电脑开机了");
}
@end

// 书类
@interface Book : NSObject {
    @public
    NSString *_name;
    int _number;
    NSString *_zuoZhe;
    int _jiaGe;
    int _pageNum;
}
- (void) show;
@end

@implementation Book
- (void) show{
    NSLog(@"%@,%d,%@,%d,%d",_name,_number,_zuoZhe,_jiaGe,_pageNum);
}
@end

// 手机类
@interface Phone : NSObject {
    @public
    NSString *_color;
    NSString *_size;
    NSString *_cpu;
}
- (void) aboutMyPhone;
- (void) callWith:(NSString *)number;
- (void) sendMessageTo:(NSString *)number messageIs:(NSString *)message;
@end

@implementation Phone
- (void) aboutMyPhone{
    NSLog(@"电话颜色%@,大小%@,cpu是%@",_color,_size,_cpu);
}
- (void) callWith:(NSString *)number{
    NSLog(@"打电话给%@", number);
}
- (void) sendMessageTo:(NSString *)number messageIs:(NSString *)message{
    NSLog(@"发消息给%@, 内容是%@", number, message);
}
@end

int main(int argc, const char * argv []){
    Phone *p1 = [Phone new];
    p1->_color = @"red";
    p1->_size = @"100*100*100";
    p1->_cpu = @"A19";
    [p1 aboutMyPhone];
    [p1 callWith:@"13888888888"];
    [p1 sendMessageTo:@"13888888888" messageIs:@"hello"];
    return 0;
}
